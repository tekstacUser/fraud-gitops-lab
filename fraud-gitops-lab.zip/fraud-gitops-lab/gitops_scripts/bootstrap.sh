#!/usr/bin/env bash
# One-time cluster setup on minikube: image + Argo CD (if missing) + the Argo CD Application.
# Usage:  ./gitops_scripts/bootstrap.sh https://gitlab.com/<you>/fraud-gitops-lab.git
# Prerequisite: this repo is pushed to that URL on branch main, and the GitLab project is Public
# (Argo CD pulls from GitLab, not from your disk).
set -euo pipefail
REPO_URL="${1:?usage: bootstrap.sh <gitlab repo url, e.g. https://gitlab.com/<you>/fraud-gitops-lab.git>}"
IMAGE=fraud-service:1.0
cd "$(dirname "$0")/.."

case "$REPO_URL" in
  http://*|https://*) ;;
  *) echo "Use the HTTPS clone URL (https://gitlab.com/<you>/fraud-gitops-lab.git), not SSH." >&2; exit 1 ;;
esac

# 1. Cluster
minikube status >/dev/null 2>&1 || minikube start
kubectl config use-context minikube
echo "kubectl context: $(kubectl config current-context)"

# 2. Image, built straight into minikube (works with the containerd runtime; no docker-env needed)
if ! minikube image build -t "$IMAGE" .; then
  echo "minikube image build failed; falling back to docker build + minikube image load"
  docker build -t "$IMAGE" .
  minikube image load "$IMAGE"
fi
minikube image ls | grep -q "fraud-service:1.0" || { echo "image $IMAGE not found in minikube" >&2; exit 1; }

# 3. Argo CD (skipped if already installed)
if ! kubectl get ns argocd >/dev/null 2>&1; then
  kubectl create namespace argocd
  kubectl apply -n argocd --server-side --force-conflicts \
    -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
fi
kubectl -n argocd rollout status deploy/argocd-server --timeout=900s
kubectl -n argocd rollout status deploy/argocd-repo-server --timeout=900s

# 4. The Application that watches your GitLab repo
sed "s#REPLACE_WITH_YOUR_REPO_URL#${REPO_URL}#" argocd/application.yaml | kubectl apply -f -
kubectl -n argocd annotate application fraud-service argocd.argoproj.io/refresh=hard --overwrite

echo
echo "Argo CD admin password (if rejected, it was changed after install; see the guide, Step 3d):"
kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath='{.data.password}' 2>/dev/null | base64 -d || true; echo
echo
echo "UI:       kubectl -n argocd port-forward svc/argocd-server 8080:443   ->  https://localhost:8080  (user: admin)"
echo "Service:  kubectl -n fraud port-forward svc/fraud-service 9000:80   (on a shared VM use --address 127.0.0.1 ... 19000:80)"
echo "Watch:    kubectl -n argocd get application fraud-service -w"
